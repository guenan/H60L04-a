﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PartA.Models {
    public class FizzBuzz {
        public List<string> getList() {
            throw new NotImplementedException("Not yet implemented");
        }
    }
}
